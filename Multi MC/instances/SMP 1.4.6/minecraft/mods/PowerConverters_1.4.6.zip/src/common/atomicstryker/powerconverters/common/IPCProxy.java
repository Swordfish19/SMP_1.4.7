package atomicstryker.powerconverters.common;

import net.minecraft.network.packet.Packet;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public interface IPCProxy
{
	public String getConfigPath();
	
	public void sendPacketToAll(Packet packet);
	
	public boolean isClient(World world);
	
	public boolean isServer();
	
	public Packet getTileEntityPacket(TileEntity te, int liqInt);
	
	public void sendPacket(Packet packet);
}
