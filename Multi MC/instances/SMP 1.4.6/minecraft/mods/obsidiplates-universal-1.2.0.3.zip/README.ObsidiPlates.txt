Obsidian Pressure Plates v1.2.0 build 3 (for Minecraft v1.4.6)    -by- Myrathi
------------------------------------------------------------------------------------------

Q. What does this mod do?
A. It provides pressure plates that are only activated by players.

Q. How do I install it?
A. You place the ZIP file into the client's (and server's, if SMP) /mods folder.

Q. Do I need anything else to use it?
A. You'll need: Forge (recommended build 467+)

Q. How do the plates work?
A. You place them and stand on them.

Q. Ok... how do I make the things?
A. You'll need a 3x3 crafting matrix and some obsidian:

   Obsidian Pressure Plate
         [ ] [ ] [ ]
         [ ] [ ] [ ]
         [#] [#] [ ]

     # - Obsidian Block

Q. Are we done, yet?
A. We are. Enjoy your new toys!

==========
Change Log
----------
v1.2.0.3 - Update for Minecraft 1.4.6
v1.1.0.2 - Update for Minecraft 1.4.5
v1.0.0.1 - Initial release

==========
[b]ObsidiPlates[/b] is licensed under a 'Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License'.

License: http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_GB
Mod Thread: http://bit.ly/ObsidiPlates
