package ro.narc.liquiduu;

public class CommonProxy {
    public void init() { };
}
